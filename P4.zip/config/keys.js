module.exports={
    MongoURI:'mongodb+srv://P3User:P3Password@cluster0.lamkh.mongodb.net/P3?retryWrites=true&w=majority'
}